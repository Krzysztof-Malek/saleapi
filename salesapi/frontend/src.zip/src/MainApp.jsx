import React, { useState } from "react";
import InventoryPanel from "./InventoryPanel";
import SalesPanel from "./SalesPanel";
import StockXHistoryPanel from "./StockXHistoryPanel";
import { Button } from "./components/ui/button";

export default function MainApp() {
    const [tab, setTab] = useState("inventory");

    return (
        <div className="p-6">
            <div className="flex gap-4 mb-6">
                <Button onClick={() => setTab("inventory")} variant={tab === "inventory" ? "default" : "outline"}>Magazyn</Button>
                <Button onClick={() => setTab("sales")} variant={tab === "sales" ? "default" : "outline"}>Sprzedaż</Button>
                <Button onClick={() => setTab("history")} variant={tab === "history" ? "default" : "outline"}>Historia sprzedaży</Button>
            </div>

            {tab === "inventory" && <InventoryPanel />}
            {tab === "sales" && <SalesPanel />}
            {tab === "history" && <StockXHistoryPanel />}
        </div>
    );
}
