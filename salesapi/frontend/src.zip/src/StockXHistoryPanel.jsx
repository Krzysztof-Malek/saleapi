import React, { useEffect, useState } from "react";
import axios from "axios";

export default function StockXHistoryPanel() {
    const [orders, setOrders] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        axios.get("/api/stockx/history")
            .then((res) => {
                const hits = res.data?.Payload?.Orders || [];
                setOrders(hits);
            })
            .catch((err) => {
                setError("Nie udało się pobrać historii sprzedaży z StockX.");
            });
    }, []);

    return (
        <div className="space-y-4">
            <h2 className="text-2xl font-bold">Historia sprzedaży (StockX)</h2>
            {error && <p className="text-red-500">{error}</p>}
            <ul className="space-y-2">
                {orders.map((order, index) => (
                    <li key={index} className="border rounded p-4">
                        <div><strong>Produkt:</strong> {order.product.name}</div>
                        <div><strong>Rozmiar:</strong> {order.shoeSize}</div>
                        <div><strong>Cena:</strong> {order.amount} {order.currency}</div>
                        <div><strong>Status:</strong> {order.state}</div>
                    </li>
                ))}
                {orders.length === 0 && !error && <p>Brak danych sprzedaży.</p>}
            </ul>
        </div>
    );
}
